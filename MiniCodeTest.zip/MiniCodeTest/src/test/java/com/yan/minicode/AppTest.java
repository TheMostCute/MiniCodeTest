package com.yan.minicode;

import org.junit.Test;

import java.util.List;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    @Test
    public void testConverter() {
        List<String> converter = PhoneNumberConverter.INSTANCE.converter(59);
        System.out.println(converter);
    }
}
